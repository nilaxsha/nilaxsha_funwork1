SC.initialize({
  client_id: '340f063c670272fac27cfa67bffcafc4'
});

$(document).ready(function() {  });
SC.stream('/tracks/296037065',function(sound){ });

$('#start1').click(function(e) {
           e.preventDefault();
           sound.start();
         });

  $('#stop1').click(function(e) {
              e.preventDefault();
              sound.stop();
            });
SC.stream('/tracks/46433404',function(sound){ });

$('#start2').click(function(e) {
           e.preventDefault();
           sound.start();
         });

  $('#stop2').click(function(e) {
              e.preventDefault();
              sound.stop();
            });

SC.stream('/tracks/431444451',function(sound){ });

$('#start3').click(function(e) {
           e.preventDefault();
           sound.start();
         });

  $('#stop3').click(function(e) {
              e.preventDefault();
              sound.stop();
            });
 SC.stream('/tracks/61139505',function(sound){ });
  $('#start4').click(function(e) {
             e.preventDefault();
              sound.start();
              });

  $('#stop4').click(function(e) {
            e.preventDefault();
            sound.stop();
            });
            SC.stream('/tracks/27064739',function(sound){ });
             $('#start5').click(function(e) {
                        e.preventDefault();
                         sound.start();
                         });

             $('#stop5').click(function(e) {
                       e.preventDefault();
                       sound.stop();
                       });
            SC.stream('/tracks/37103455',function(sound){ });
             $('#start6').click(function(e) {
                        e.preventDefault();
                         sound.start();
                         });

             $('#stop6').click(function(e) {
                       e.preventDefault();
                       sound.stop();
                       });

      SC.stream('/tracks/674421794',function(sound){ });

      $('#start7').click(function(e) {
                 e.preventDefault();
                 sound.start();
                  });

          $('#stop7').click(function(e) {
                    e.preventDefault();
                    sound.stop();
                      });
  SC.stream('/tracks/327110130',function(sound){ });

    $('#start11').click(function(e) {
              e.preventDefault();
              sound.start();
                });

    $('#stop11').click(function(e) {
              e.preventDefault();
              sound.stop();
                });
